import scrapy
import datetime as dt
import logging

logging.basicConfig(
    filename='log.txt',
    format='%(levelname)s: %(message)s',
    level=logging.ERROR
)


class IsinSpider(scrapy.Spider):
    name = 'isins'
    start_urls = [
        'https://www.isin.ru/en/ru_isin/news_c/?page22=1'
    ]

    def parse(self, response):

        for isin_link in response.css('div.news_sep'):
            next_page=isin_link.css('a::attr("href")').get()
            yield response.follow(next_page, self.parse_table)
        next_page = response.request.url
        position=next_page.find('=')
        print(next_page)
        next_page = next_page[:position]+'='+str(int(next_page[position+1])+1)
        try:
            yield scrapy.Request(next_page, callback=self.parse)
        except:
            pass

    def parse_table(self, response):
        elements = response.css('td.content tr td ::text').getall()
        print(dt.datetime.timestamp)
        try:
            position = elements.index('Maturity Date')
            yield {
                'Link': response.request.url,
                'Date': elements[3],
                'Issuer': elements[5],
                'ISIN': elements[1],
                'Maturity Date': elements[position + 1],
                str(dt.datetime.utcnow()): str(dt.datetime.timestamp)
            }

        except:
            yield {
                'Link': response.request.url,
                'Date': elements[3],
                'Issuer': elements[5],
                'ISIN': elements[1],
                'Maturity Date': None,
                str(dt.datetime.utcnow()): str(dt.datetime.timestamp)
            }
