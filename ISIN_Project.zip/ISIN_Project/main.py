import requests
from urllib import request
from urllib.request import urlopen
from bs4 import BeautifulSoup
import urllib
import datetime
from datetime import date
import xlwt
from xlwt import Workbook

page_link = "https://www.isin.ru/ru/ru_isin/news_c/"
page = urllib.request.urlopen(page_link)
soup = BeautifulSoup(page, features="html.parser")
date_today = date.today()
print(date_today)
ISIN_file = Workbook("ISIN_checks.xlsx")

list_of_links = []

date_tags = soup(class_="date2 border_date2")
for date_tag in date_tags:


all_a = soup.select(".news_sep a")
for a in all_a:
    ISIN_link = page_link + a["href"]

    list_of_links.append(ISIN_link)


ISIN_link = soup(class_="news_sep")
for isin_tag in ISIN_link:
    isin_tag.find_all(attr_="href")


#print(list_of_links)
    #list_of_isins = []
    #list_of_isindates = []
    #list_of_emitents = []
    #list_of_tax = []
    #list_of_maturedate = []


    #def read_links_ISINS (list_of_links):
        #for link in list_of_links:
            #isin_page = urllib.request.urlopen(link)
           # isin_soup = BeautifulSoup(isin_page, features="html.parser")
          #  isinpage_tag = isin_soup (class_="content")
           # print(soup.td.content.table.tbody.tr.td)


#read_links_ISINS(list_of_links)